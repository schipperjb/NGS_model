
import debruijn as db
import random
def random_seq(lenseq,lowsizechop,highsizechop):
    configseq = open('SequenceFile.txt','w')
    nucleotide = 'C G T A A T C G'.split()
    seq = ''
    if highsizechop >= lenseq:
        highsizechope = int(lenseq/3)
    elif lowsizechop <= 0:
        lowsizechope = 1
    lastrand = 0
    lastlastrand =0
    nuc = 0
    for i in range(lenseq):
        nuc = random.randint(0,7)
        lastrand = nuc
        lastlastrand = lastrand
        seq = seq + nucleotide[nuc]
    #configseq.write('The genome sequence is '+seq+'\n')
    #seq = seq + '\n'
    #j = 0
    #string = ''
    #while j != 10:
        #string = string + seq + '\n'
        #j+=1
    #configseq.write('WGA of sample '+seq+' \n') 


    chop_list = []

    configseq.write(seq[0:4]+"\n")
    configseq.write(seq[lenseq-4:lenseq]+"\n")
    for i in range(10):
        endclip = random.randint(6,10)
        configseq.write(seq[0:endclip]+"\n")
        configseq.write(seq[lenseq-endclip:lenseq]+"\n")
    i = 0 
    while i < 1000:
        i+=1
        locatchop = random.randint(0,lenseq-1)
        rsizechop = random.uniform(lowsizechop,highsizechop)
        if rsizechop <2:
            rsizechop =2
        halfsizechop = int(rsizechop/2)
        startchop = locatchop -halfsizechop
        endchop = locatchop+halfsizechop
        if endchop > lenseq:
             endchop = lenseq-1
        if startchop < 0:
            startchop =0
        chop_list.append(seq[startchop:endchop])
        configseq.write(seq[startchop:endchop]+"\n")

    configseq.close()
    return(seq)
    


#filen = input('Enter filename: ')
nseq = 1 #int(input('Enter number of sequences: '))If we want to run multiple assemblies
default = 'y' #input('Default values y/n')
if default == 'y':
    bp = 30
    hsize =20
    lsize =18
else:
    bp = int(input('Enter size of the Genome in bp:'))
    hsize = int(input('highsize uniformchop:'))
    lsize = int(input('lowsize uniformchop'))
print('The random sequence generated is ')
print(random_seq(bp,lsize,hsize))

fname = 'SequenceFile.txt'
#fname = 'g200reads.fa'
reads = db.read_reads(fname)
# print reads

test = ['bcdefg', 'defghi', 'abcd']
# g = construct_graph(test, 3)
g = db.construct_graph(reads, 11)
# print_graph(g)
# for k in g.keys():
#   print k, g[k]
# g = construct_graph(reads)
contig = db.output_contigs(g)
db.export_graph(g)
print('The algorithm assembled  ')
print (contig)


