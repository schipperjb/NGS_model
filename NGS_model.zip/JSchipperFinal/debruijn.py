class Node:
    """ Class Node to represent a vertex in the de bruijn graph """
    def __init__(self, lab):
        self.label = lab
        self.indegree = 0
        self.outdegree = 0

class Edge:
    def __init__(self, lab):
        self.label = lab

def read_reads(fname):
    """ Read short reads in FASTA format. It is assumed that one line in the input file correspond to one read. """
    f = open(fname, 'r')
    lines = f.readlines()
    f.close()
    reads = []

    for line in lines:
        if line[0] != '>':
            reads = reads + [line.rstrip()]

    return reads

def construct_graph(reads, k):
    """ Construct de bruijn graph from sets of short reads with k length word"""
    fkmer = open("fkmerdebug.txt","w")
    
    edges = dict()
    vertices = dict()

    for read in reads:
        i = 0
        while i+k < len(read):
            v1 = read[i:i+k]
            v2 = read[i+1:i+k+1]
            fkmer.write('Subseq ='+read+ '  ')
            fkmer.write('   V1='+ v1 + '     V2='+ v2+'\n')
            if v1 in edges.keys():
                vertices[v1].outdegree += 1
                edges[v1] += [Edge(v2)]
                fkmer.write('#7: Within the same subseq new edge is added to Dictionary: Creating out edge from next k-mers = '+ v1 + ' to '+v2+'\n')
            else:
                fkmer.write('#1: Creating first k-mer of subseq that ='+v1+'\n')
                vertices[v1] = Node(v1)
                
                fkmer.write('#2: Creating '+v1+' as Node class and adding value to vertices dictonary \n')
                vertices[v1].outdegree += 1
                
                fkmer.write('#3: Since '+v1+' is the first k-mer of subseq and therefore outdegree added \n')
                edges[v1] = [Edge(v2)]
                
                fkmer.write('#4: Adding edge to Dictionary: Creating an out edge from '+v1+' to '+ v2+' and adding value to Edge class\n')
            if v2 in edges.keys():
                vertices[v2].indegree += 1
                fkmer.write('#7: Moving through subseq: Adding an in edge for ='+ v2+'\n')
            else:
                vertices[v2] = Node(v2) 
                fkmer.write('#5: Second k-mer '+v2+' added to edge list and defined as Node class \n#6: Indegree edge added for k-mer ='+v2+'\n')
                vertices[v2].indegree += 1
                edges[v2] = []
            i += 1
    fkmer.write('Final: All subsequences have been analyzed creating edges and potential vertices \n Graph is ready to be configured: Open contigsdebug.txt')
    fkmer.close()

    return (vertices, edges)

def output_contigs(g):
    """ Perform searching for Eulerian path in the graph to output genome assembly"""
    contigs = open("contigsdebug.txt","w")
    V = g[0] #vector class: set first vertice to be the starting node
    E = g[1] #edge class: not including starting node
    # Pick starting node (the vertex with zero in degree)

    start = list(V)[0]       #.keys()[0] 

        
    contigs.write(E[start][0].label)
    #contigs.write('The last edge formed was '+ start+'\n')
    for k in V.keys(): #loop through all the nodes k is the 3 kmer label
        if V[k].indegree < V[start].indegree:
            start = k #searching for the largest indegree in the list of substrings
    contigs.write("Node with smallest indegree will be selected to start Eulerian cycle \nThis node is " + k+ "\n")
    contig = start
    current = start
    while len(E[current]) > 0:
        # Pick the next node to be traversed (for now, at random)
        contigs.write("There is  " +str(len(E[current]))+' edges present at node '+ contig)
        next = E[current][0]
        contigs.write("\nBeing added to the sequence assembly is  "+str(current)+'then removed from objects list')
        del E[current][0]
        contig += next.label[-1]
        contigs.write('\n'+ 'Building from starting node this is the updated sequence = '+ contig)
        current = next.label
        contigs.write('\n'+ 'Moving forward in this sequence the next node to be evaluated is = '+ current)
    contigs.write("\n Sequence as been assemble = "+contig)
    contigs.close()
    return contig
    
def print_graph(g):
    """ Print the information in the graph to be (somewhat) presentable """
    graph = open("graph.txt",'w')
    V = g[0]
    E = g[1]
    for k in V.keys():
        graph.write("name: "+V[k].label+ ". indegree: "+ str(V[k].indegree)+ ". outdegree: "+ str(V[k].outdegree)+ '\n')
        graph.write( "Edges: \n")
        for e in E[k]:
            graph.write(e.label+'\n')
        print()
    
def export_graph(g):
    """ Print the information in the graph to be (somewhat) presentable """
    graph = open("graph.txt",'w')
    Ncsvgraph = open("Nodegraph.csv",'w')
    Ecsvgraph = open("Edgegraph.csv",'w')
    V = g[0]
    E = g[1]
    Ncsvgraph.write('Id;Label\n')
    Ecsvgraph.write('Source;Target;Type\n')         
     
    for k in V.keys():
        Ncsvgraph.write('"'+V[k].label+'";"'+V[k].label+'"\n')
        for e in E[k]:
            Ecsvgraph.write('"'+V[k].label+'";"'+e.label+'";Directed\n')
        
    graph.write("name: "+V[k].label+ ". indegree: "+ str(V[k].indegree)+ ". outdegree: "+ str(V[k].outdegree)+ '\n')
    graph.write( "Edges: \n")
    for e in E[k]:
            graph.write(e.label+'\n')
    graph.close()
    Ncsvgraph.close()
    Ecsvgraph.close()
